class Class1{
    constructor(attr1, attr2, attr3, attr4, attr5, attr6, attr7, attr8){
        this._attr1 = attr1;
        this._attr2 = attr2;
        this._attr3 = attr3;
        this._attr4 = attr4;
        this._attr5 = attr5;
        this._attr6 = attr6;
        this._attr7 = attr7;
        this._attr8 = attr8;
    }

    get attr1(){
        return this._attr1;
    }

    set attr1(attr1){
        this._attr1 = attr1;
    }

    get attr2(){
        return this._attr2;
    }

    set attr2(attr2){
        this._attr2 = attr2;
    }

    get attr3(){
        return this._attr3;
    }

    set attr3(attr3){
        this._attr3 = attr3;
    }

    get attr4(){
        return this._attr4;
    }

    set attr4(attr4){
        this._attr4 = attr4;
    }

    get attr5(){
        return this._attr5;
    }

    set attr5(attr5){
        this._attr5 = attr5;
    }

    get attr6(){
        return this._attr6;
    }

    set attr6(attr6){
        this._attr6 = attr6;
    }

    get attr7(){
        return this._attr7;
    }

    set attr7(attr7){
        this._attr7 = attr7;
    }

    get attr8(){
        return this._attr8;
    }

    set attr8(attr8){
        this._attr8 = attr8;
    }
}