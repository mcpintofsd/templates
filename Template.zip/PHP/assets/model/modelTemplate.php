<?php

require_once 'connection.php';

class Template{

    function firstFunction($id, $name, $address, $phone, $email, $type){
        
    }
}

?>